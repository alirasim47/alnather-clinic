"use client";
import React, { useState, useMemo } from "react";
import { Card, Badge, Input, Select, Field, Modal, EmptyRow } from "@/components/ui";
import { seedInvoices, seedPatients, seedProducts, payAr } from "@/lib/data";
import { fmtMoney, fmtDate } from "@/lib/utils";

const pName = (id) => seedPatients.find((p) => p.id === id)?.name || "عميل نقدي";

export default function Invoices() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [pos, setPos] = useState(false);

  const filtered = useMemo(() => seedInvoices.filter((i) => {
    if (status !== "all" && i.status !== status) return false;
    if (from && i.date < from) return false;
    if (to && i.date > to) return false;
    if (query && !pName(i.patientId).includes(query) && !i.no.includes(query)) return false;
    return true;
  }), [query, status, from, to]);

  const stBadge = (s) => s === "paid" ? <Badge color="green">مدفوعة</Badge>
    : s === "partial" ? <Badge color="orange">جزئي</Badge> : <Badge color="red">غير مدفوعة</Badge>;

  return (
    <div className="space-y-5">
      <Card className="flex flex-wrap items-end gap-4 p-4">
        <Field label="من تاريخ"><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
        <Field label="إلى تاريخ"><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></Field>
        <Field label="بحث"><Input placeholder="رقم الفاتورة أو اسم المريض" value={query} onChange={(e) => setQuery(e.target.value)} /></Field>
        <Field label="حالة الدفع">
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">الكل</option><option value="paid">نقدي / مدفوع</option>
            <option value="partial">أقساط / جزئي</option><option value="unpaid">غير مدفوع</option>
          </Select>
        </Field>
        <button onClick={() => setPos(true)} className="btn-accent mr-auto"><i className="fa-solid fa-plus" /> فاتورة جديدة (POS)</button>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr><th className="th">رقم الفاتورة</th><th className="th">التاريخ</th><th className="th">المريض</th>
                <th className="th">الإجمالي</th><th className="th">المدفوع</th><th className="th">المتبقي</th>
                <th className="th">طريقة الدفع</th><th className="th">إجراءات</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 && <EmptyRow span={8} />}
              {filtered.map((i) => {
                const rem = i.total - i.paid;
                return (
                  <tr key={i.id} className="hover:bg-accent-soft/40">
                    <td className="td font-bold"><Badge color="yellow">{i.no}</Badge></td>
                    <td className="td text-gray-500">{fmtDate(i.date)}</td>
                    <td className="td font-bold text-gray-800">{pName(i.patientId)}</td>
                    <td className="td">{fmtMoney(i.total)}</td>
                    <td className="td font-bold text-success">{fmtMoney(i.paid)}</td>
                    <td className={`td font-bold ${rem > 0 ? "text-danger" : "text-gray-400"}`}>{fmtMoney(rem)}</td>
                    <td className="td">{payAr[i.method]}</td>
                    <td className="td">
                      <div className="flex gap-1">
                        <button title="طباعة" className="icon-btn text-primary hover:bg-primary hover:text-white"><i className="fa-solid fa-print" /></button>
                        <button title="عرض" className="icon-btn text-info hover:bg-info hover:text-white"><i className="fa-solid fa-eye" /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {pos && <PosModal onClose={() => setPos(false)} />}
    </div>
  );
}

function PosModal({ onClose }) {
  const [items, setItems] = useState([]);
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState(1);
  const [discount, setDiscount] = useState(0);
  const [paid, setPaid] = useState(0);

  const addItem = () => {
    const prod = seedProducts.find((p) => p.id === Number(productId));
    if (!prod) return;
    setItems([...items, { id: Date.now(), name: prod.name, price: prod.sell, qty: Number(qty) }]);
    setProductId(""); setQty(1);
  };

  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const total = Math.max(0, subtotal - Number(discount || 0));
  const remaining = Math.max(0, total - Number(paid || 0));

  return (
    <Modal open onClose={onClose} wide title="إنشاء فاتورة جديدة — نقطة البيع">
      <div className="space-y-5">
        <div className="flex items-end gap-3">
          <div className="flex-1">
            <Field label="المنتج / الخدمة">
              <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
                <option value="">— اختر منتجاً —</option>
                {seedProducts.map((p) => <option key={p.id} value={p.id}>{p.name} — {fmtMoney(p.sell)}</option>)}
              </Select>
            </Field>
          </div>
          <Field label="الكمية"><Input type="number" min="1" className="w-24" value={qty} onChange={(e) => setQty(e.target.value)} /></Field>
          <button onClick={addItem} className="btn-accent mb-0.5"><i className="fa-solid fa-plus" /> إضافة</button>
        </div>

        <table className="w-full overflow-hidden rounded-xl2 border border-gray-100">
          <thead className="bg-gray-50"><tr><th className="th">الصنف</th><th className="th">السعر</th><th className="th">الكمية</th><th className="th">الإجمالي</th><th className="th"></th></tr></thead>
          <tbody className="divide-y divide-gray-50">
            {items.length === 0 && <EmptyRow span={5} text="لم تتم إضافة أصناف بعد" />}
            {items.map((i) => (
              <tr key={i.id}>
                <td className="td font-bold">{i.name}</td><td className="td">{fmtMoney(i.price)}</td>
                <td className="td">{i.qty}</td><td className="td font-bold">{fmtMoney(i.price * i.qty)}</td>
                <td className="td"><button className="icon-btn text-danger hover:bg-danger hover:text-white" onClick={() => setItems(items.filter((x) => x.id !== i.id))}><i className="fa-solid fa-trash" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <Field label="الخصم"><Input dir="ltr" type="number" min="0" value={discount} onChange={(e) => setDiscount(e.target.value)} /></Field>
          <Field label="المبلغ المدفوع"><Input dir="ltr" type="number" min="0" value={paid} onChange={(e) => setPaid(e.target.value)} /></Field>
          <div className="space-y-2 rounded-xl2 bg-primary p-4 text-white">
            <div className="flex justify-between text-sm"><span>الإجمالي الفرعي</span><b>{fmtMoney(subtotal)}</b></div>
            <div className="flex justify-between text-sm"><span>الإجمالي النهائي</span><b className="text-accent">{fmtMoney(total)}</b></div>
            <div className="flex justify-between text-sm"><span>المتبقي</span><b className={remaining > 0 ? "text-red-300" : "text-emerald-300"}>{fmtMoney(remaining)}</b></div>
          </div>
        </div>

        <div className="flex justify-end gap-3 border-t border-gray-100 pt-4">
          <button onClick={onClose} className="btn-outline-danger">إلغاء</button>
          <button onClick={() => { alert("تم حفظ الفاتورة بنجاح ✅"); onClose(); }} className="btn-accent"><i className="fa-solid fa-floppy-disk" /> حفظ الفاتورة</button>
        </div>
      </div>
    </Modal>
  );
}
