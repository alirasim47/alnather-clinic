"use client";
import React, { useState } from "react";
import { Card, Field, Input } from "@/components/ui";

const TABS = [
  { id: "clinic", label: "إعدادات العيادة", icon: "fa-hospital" },
  { id: "wa", label: "قوالب واتساب", icon: "fa-brands fa-whatsapp" },
  { id: "backup", label: "النسخ الاحتياطي", icon: "fa-database" },
  { id: "updates", label: "التحديثات", icon: "fa-cloud-arrow-down" },
];

export default function Settings() {
  const [tab, setTab] = useState("clinic");
  const [color, setColor] = useState("#2c1b3d");

  return (
    <div className="space-y-5">
      <div className="flex gap-2 rounded-xl2 bg-white p-2 shadow-card">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold transition
              ${tab === t.id ? "bg-primary text-accent" : "text-gray-500 hover:bg-gray-100"}`}>
            <i className={`fa-solid ${t.icon}`} /> {t.label}
          </button>
        ))}
      </div>

      {tab === "clinic" && (
        <Card className="p-6">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="space-y-4 lg:col-span-2">
              <Field label="اسم العيادة"><Input defaultValue="الناظر" /></Field>
              <div className="grid grid-cols-2 gap-4">
                <Field label="رقم الهاتف 1"><Input dir="ltr" defaultValue="0112345678" /></Field>
                <Field label="رقم الهاتف 2"><Input dir="ltr" placeholder="اختياري" /></Field>
              </div>
              <Field label="نص تذييل الفواتير"><textarea className="input min-h-16" defaultValue="شكراً لزيارتكم — نسعد بخدمتكم" /></Field>
              <Field label="اللون الأساسي للنظام">
                <div className="flex items-center gap-3">
                  <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-11 w-16 cursor-pointer rounded-lg border border-gray-300" />
                  <Input dir="ltr" value={color} onChange={(e) => setColor(e.target.value)} className="w-32" />
                  <span className="h-8 w-8 rounded-lg" style={{ background: color }} />
                </div>
              </Field>
            </div>
            <div className="space-y-4">
              <Field label="شعار العيادة">
                <label className="flex h-32 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl2 border-2 border-dashed border-gray-300 text-gray-400 transition hover:border-accent hover:text-accent">
                  <i className="fa-solid fa-cloud-arrow-up text-2xl" /><span className="text-xs font-bold">اضغط لرفع الشعار</span>
                  <input type="file" accept="image/*" className="hidden" />
                </label>
              </Field>
              <div className="rounded-xl2 border border-gray-100 p-4 text-center">
                <div className="mx-auto grid h-32 w-32 grid-cols-8 gap-0.5 rounded-lg border border-gray-200 p-2">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <span key={i} className={`rounded-[1px] ${i % 3 === 0 ? "bg-primary" : "bg-white"}`} />
                  ))}
                </div>
                <p className="mt-2 text-[11px] text-gray-400">رمز QR للعيادة (توليد تلقائي)</p>
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end gap-3 border-t border-gray-100 pt-4">
            <button className="btn-outline-danger">إلغاء</button>
            <button className="btn-accent"><i className="fa-solid fa-floppy-disk" /> حفظ الإعدادات</button>
          </div>
        </Card>
      )}

      {tab === "wa" && (
        <Card className="p-6">
          <Field label="قالب تذكير المراجعة — المتغيرات: {name} {date} {time} {clinic}">
            <textarea className="input min-h-32" defaultValue={"مرحباً {name} 👋\nنذكركم بموعد المراجعة في عيادة {clinic} بتاريخ {date} الساعة {time}."} />
          </Field>
          <div className="mt-4 flex justify-end"><button className="btn-accent"><i className="fa-solid fa-floppy-disk" /> حفظ القالب</button></div>
        </Card>
      )}

      {tab === "backup" && (
        <Card className="p-6">
          <div className="flex items-center justify-between rounded-xl2 border border-gray-100 p-4">
            <div><div className="font-extrabold text-primary">آخر نسخة احتياطية</div><div className="text-sm text-gray-500">اليوم — 03:00 صباحاً (تلقائي)</div></div>
            <div className="flex gap-3">
              <button className="btn-blue"><i className="fa-solid fa-download" /> تنزيل نسخة</button>
              <button className="btn-accent"><i className="fa-solid fa-upload" /> رفع نسخة</button>
            </div>
          </div>
        </Card>
      )}

      {tab === "updates" && (
        <Card className="p-6 text-center">
          <i className="fa-solid fa-circle-check mb-3 text-4xl text-success" />
          <div className="text-lg font-extrabold text-primary">النظام محدّث — الإصدار 1.0.0</div>
          <p className="mt-1 text-sm text-gray-500">آخر تحقق من التحديثات: اليوم</p>
          <button className="btn-accent mt-4"><i className="fa-solid fa-rotate" /> التحقق من التحديثات</button>
        </Card>
      )}
    </div>
  );
}
