"use client";
import React, { useState } from "react";
import { Card, Toggle, Badge, Modal, Field, Input, Select, EmptyRow } from "@/components/ui";
import { seedExaminers } from "@/lib/data";

export default function Examiners() {
  const [list, setList] = useState(seedExaminers);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", phone: "", role: "أخصائي بصريات" });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black text-primary">الفاحصون والكادر الطبي</h2>
        <button onClick={() => setOpen(true)} className="btn-accent"><i className="fa-solid fa-plus" /> إضافة فاحص</button>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr><th className="th">اسم الفاحص</th><th className="th">الجوال</th><th className="th">المسمى الوظيفي</th><th className="th">الحالة</th><th className="th">إجراءات</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {list.length === 0 && <EmptyRow span={5} />}
              {list.map((x) => (
                <tr key={x.id} className="hover:bg-accent-soft/40">
                  <td className="td font-bold text-gray-800"><i className="fa-solid fa-user-doctor ml-2 text-primary" />{x.name}</td>
                  <td className="td" dir="ltr">{x.phone}</td>
                  <td className="td"><Badge color="blue">{x.role}</Badge></td>
                  <td className="td">
                    <div className="flex items-center gap-2">
                      <Toggle on={x.active} onChange={(v) => setList(list.map((i) => i.id === x.id ? { ...i, active: v } : i))} />
                      <span className={`text-xs font-bold ${x.active ? "text-success" : "text-gray-400"}`}>{x.active ? "نشط" : "موقوف"}</span>
                    </div>
                  </td>
                  <td className="td">
                    <div className="flex gap-1">
                      <button className="icon-btn text-info hover:bg-info hover:text-white"><i className="fa-solid fa-pen" /></button>
                      <button className="icon-btn text-danger hover:bg-danger hover:text-white" onClick={() => setList(list.filter((i) => i.id !== x.id))}>
                        <i className="fa-solid fa-trash" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {open && (
        <Modal open onClose={() => setOpen(false)} title="إضافة فاحص جديد">
          <form className="space-y-4" onSubmit={(e) => {
            e.preventDefault();
            if (!f.name) return;
            setList([...list, { id: Date.now(), ...f, active: true }]);
            setOpen(false); setF({ name: "", phone: "", role: "أخصائي بصريات" });
          }}>
            <Field label="اسم الفاحص" required><Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
            <Field label="رقم الجوال"><Input dir="ltr" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
            <Field label="المسمى الوظيفي">
              <Select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>
                <option>أخصائي بصريات</option><option>طبيب عيون</option><option>فني بصريات</option>
              </Select>
            </Field>
            <div className="flex justify-end gap-3 border-t border-gray-100 pt-4">
              <button type="button" onClick={() => setOpen(false)} className="btn-outline-danger">إلغاء</button>
              <button type="submit" className="btn-accent"><i className="fa-solid fa-floppy-disk" /> حفظ</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
