"use client";
import React, { useState, useMemo } from "react";
import { Card, Modal, Field, Input, Badge, EmptyRow } from "@/components/ui";
import { seedPatients, seedExams, seedExaminers } from "@/lib/data";
import { fmtMoney, fmtDate, printPrescription, openWhatsApp, todayISO } from "@/lib/utils";
import ExamForm from "@/components/ExamForm";

export default function Patients() {
  const [patients, setPatients] = useState(seedPatients);
  const [exams, setExams] = useState(seedExams);
  const [query, setQuery] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [fileOf, setFileOf] = useState(null);
  const [examFor, setExamFor] = useState(null);

  const filtered = useMemo(
    () => patients.filter((p) => p.name.includes(query) || (p.phone1 || "").includes(query)),
    [patients, query]
  );

  const savePatient = (data) => {
    const id = Math.max(...patients.map((p) => p.id)) + 1;
    setPatients([...patients, { id, fileNo: `P-${1000 + id}`, lastVisit: "—", ...data }]);
    setAddOpen(false);
  };

  const removePatient = (id) => {
    if (confirm("هل أنت متأكد من حذف هذا المريض؟ سيتم حذف جميع فحوصاته."))
      setPatients(patients.filter((p) => p.id !== id));
  };

  if (fileOf) {
    const patient = patients.find((p) => p.id === fileOf);
    const pExams = exams.filter((e) => e.patientId === fileOf);
    return (
      <div className="space-y-6">
        <Card className="p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-2xl font-black text-accent">
                {patient.name.charAt(0)}
              </span>
              <div>
                <h2 className="text-xl font-black text-primary">{patient.name}</h2>
                <div className="mt-1 flex flex-wrap gap-4 text-sm text-gray-500">
                  <span><i className="fa-solid fa-hashtag ml-1 text-accent" />{patient.fileNo}</span>
                  <span><i className="fa-solid fa-phone ml-1 text-accent" />{patient.phone1}</span>
                  <span><i className={`fa-solid ${patient.gender === "male" ? "fa-mars" : "fa-venus"} ml-1 text-accent`} />{patient.gender === "male" ? "ذكر" : "أنثى"}</span>
                  <span><i className="fa-regular fa-calendar ml-1 text-accent" />آخر زيارة: {patient.lastVisit}</span>
                </div>
                {patient.notes && <p className="mt-2 rounded-lg bg-orange-50 px-3 py-1.5 text-xs font-bold text-orange-600"><i className="fa-solid fa-triangle-exclamation ml-1" />{patient.notes}</p>}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setExamFor(patient)} className="btn-accent">
                <i className="fa-solid fa-plus" /> فحص جديد
              </button>
              <button onClick={() => setFileOf(null)} className="btn-ghost">
                <i className="fa-solid fa-arrow-right" /> رجوع
              </button>
            </div>
          </div>
        </Card>

        <Card>
          <div className="border-b border-gray-100 px-5 py-4">
            <h3 className="font-extrabold text-primary"><i className="fa-solid fa-clock-rotate-left ml-2 text-accent" />سجل الفحوصات السابقة</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="th">التاريخ</th><th className="th">نوع العدسة</th><th className="th">الفاحص</th>
                  <th className="th">السعر</th><th className="th">موعد المراجعة</th><th className="th">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {pExams.length === 0 && <EmptyRow span={6} text="لا توجد فحوصات سابقة — ابدأ بإضافة فحص جديد" />}
                {pExams.map((e) => (
                  <tr key={e.id} className="hover:bg-accent-soft/40">
                    <td className="td font-bold">{fmtDate(e.date)}</td>
                    <td className="td">{e.lens}</td>
                    <td className="td">{seedExaminers.find((x) => x.id === e.examinerId)?.name}</td>
                    <td className="td font-bold text-success">{fmtMoney(e.price)}</td>
                    <td className="td">{e.reviewDate ? fmtDate(e.reviewDate) : "—"}</td>
                    <td className="td">
                      <div className="flex gap-1">
                        <button title="طباعة الوصفة" className="icon-btn text-primary hover:bg-primary hover:text-white"
                          onClick={() => printPrescription({
                            patient, exam: { date: fmtDate(e.date), examiner: seedExaminers.find(x=>x.id===e.examinerId)?.name, pd: e.pd, vaOD: e.vaOD, vaOS: e.vaOS, lens: e.lens, refraction: e.refraction, notes: e.notes },
                            rx: e.rx || { distance: { OD: {}, OS: {} }, near: { OD: {}, OS: {} } },
                            clinic: { name: "الناظر", phone: "0112345678" },
                          })}>
                          <i className="fa-solid fa-print" />
                        </button>
                        <button title="إرسال واتساب" className="icon-btn text-success hover:bg-success hover:text-white"
                          onClick={() => openWhatsApp({ phone: patient.phone1, name: patient.name, date: e.reviewDate || todayISO(), time: "10:00" })}>
                          <i className="fa-brands fa-whatsapp" />
                        </button>
                        <button title="تعديل" className="icon-btn text-info hover:bg-info hover:text-white"><i className="fa-solid fa-pen" /></button>
                        <button title="حذف" className="icon-btn text-danger hover:bg-danger hover:text-white"
                          onClick={() => setExams(exams.filter((x) => x.id !== e.id))}>
                          <i className="fa-solid fa-trash" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {examFor && (
          <ExamForm
            patient={examFor}
            onClose={() => setExamFor(null)}
            onSave={(exam) => {
              const id = Math.max(0, ...exams.map((e) => e.id)) + 1;
              setExams([...exams, { id, patientId: examFor.id, ...exam }]);
              setExamFor(null);
            }}
          />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <h2 className="text-xl font-black text-primary">المرضى</h2>
          <Badge color="yellow">{patients.length} مريض</Badge>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative w-72">
            <Input placeholder="بحث بالاسم أو رقم الجوال..." value={query} onChange={(e) => setQuery(e.target.value)} />
            <i className="fa-solid fa-magnifying-glass absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <button onClick={() => setAddOpen(true)} className="btn-accent">
            <i className="fa-solid fa-plus" /> إضافة مريض
          </button>
        </div>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="th">الاسم</th><th className="th">الجوال</th><th className="th">رقم الملف</th>
                <th className="th">آخر زيارة</th><th className="th">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 && <EmptyRow span={5} text="لا توجد نتائج مطابقة للبحث" />}
              {filtered.map((p) => (
                <tr key={p.id} className="transition hover:bg-accent-soft/40">
                  <td className="td font-bold text-gray-800">
                    <i className={`fa-solid ${p.gender === "male" ? "fa-mars text-info" : "fa-venus text-pink-500"} ml-2`} />{p.name}
                  </td>
                  <td className="td" dir="ltr">{p.phone1}</td>
                  <td className="td"><Badge color="gray">{p.fileNo}</Badge></td>
                  <td className="td text-gray-500">{p.lastVisit}</td>
                  <td className="td">
                    <div className="flex gap-1">
                      <button title="عرض الملف" className="icon-btn text-primary hover:bg-primary hover:text-white" onClick={() => setFileOf(p.id)}>
                        <i className="fa-solid fa-folder-open" />
                      </button>
                      <button title="تعديل" className="icon-btn text-info hover:bg-info hover:text-white"><i className="fa-solid fa-pen" /></button>
                      <button title="حذف" className="icon-btn text-danger hover:bg-danger hover:text-white" onClick={() => removePatient(p.id)}>
                        <i className="fa-solid fa-trash" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {addOpen && <AddPatientModal onClose={() => setAddOpen(false)} onSave={savePatient} />}
    </div>
  );
}

function AddPatientModal({ onClose, onSave }) {
  const [f, setF] = useState({ name: "", phone1: "", phone2: "", gender: "male", dob: "", address: "", notes: "" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <Modal open onClose={onClose} title="إضافة مريض جديد">
      <form onSubmit={(e) => { e.preventDefault(); if (f.name.trim()) onSave(f); }} className="space-y-4">
        <Field label="الاسم الكامل" required>
          <Input required placeholder="أدخل اسم المريض الثلاثي" value={f.name} onChange={set("name")} />
        </Field>
        <div className="grid grid-cols-2 gap-4">
          <Field label="رقم الجوال 1"><Input dir="ltr" placeholder="05xxxxxxxx" value={f.phone1} onChange={set("phone1")} /></Field>
          <Field label="رقم الجوال 2"><Input dir="ltr" placeholder="05xxxxxxxx" value={f.phone2} onChange={set("phone2")} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Field label="الجنس">
            <div className="flex items-center gap-6 rounded-lg border border-gray-300 px-3 py-2.5">
              <label className="flex cursor-pointer items-center gap-2 text-sm">
                <input type="radio" name="g" checked={f.gender === "male"} onChange={() => setF({ ...f, gender: "male" })} className="accent-yellow-500" /> ذكر
              </label>
              <label className="flex cursor-pointer items-center gap-2 text-sm">
                <input type="radio" name="g" checked={f.gender === "female"} onChange={() => setF({ ...f, gender: "female" })} className="accent-yellow-500" /> أنثى
              </label>
            </div>
          </Field>
          <Field label="تاريخ الميلاد"><Input type="date" value={f.dob} onChange={set("dob")} /></Field>
        </div>
        <Field label="العنوان"><Input placeholder="المدينة — الحي" value={f.address} onChange={set("address")} /></Field>
        <Field label="ملاحظات"><textarea className="input min-h-20" placeholder="أي ملاحظات طبية مهمة..." value={f.notes} onChange={set("notes")} /></Field>
        <div className="flex justify-end gap-3 border-t border-gray-100 pt-4">
          <button type="button" onClick={onClose} className="btn-outline-danger">إلغاء</button>
          <button type="submit" className="btn-accent"><i className="fa-solid fa-floppy-disk" /> حفظ</button>
        </div>
      </form>
    </Modal>
  );
}
