"use client";
import React, { useState } from "react";
import { Card, Toggle, Badge, EmptyRow } from "@/components/ui";
import { seedUsers, roleAr } from "@/lib/data";

export default function Users() {
  const [list, setList] = useState(seedUsers);
  const roleBadge = (r) => r === "admin" ? <Badge color="yellow">{roleAr[r]}</Badge>
    : r === "accountant" ? <Badge color="blue">{roleAr[r]}</Badge> : <Badge color="gray">{roleAr[r]}</Badge>;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-black text-primary">المستخدمون والصلاحيات</h2>
        <button className="btn-accent"><i className="fa-solid fa-plus" /> إضافة مستخدم</button>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr><th className="th">الاسم الكامل</th><th className="th">اسم المستخدم</th><th className="th">الصلاحية</th><th className="th">الحالة</th><th className="th">إجراءات</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {list.length === 0 && <EmptyRow span={5} />}
              {list.map((u) => (
                <tr key={u.id} className="hover:bg-accent-soft/40">
                  <td className="td font-bold text-gray-800">{u.name}</td>
                  <td className="td text-gray-500" dir="ltr">{u.username}</td>
                  <td className="td">{roleBadge(u.role)}</td>
                  <td className="td">
                    <div className="flex items-center gap-2">
                      <Toggle on={u.active} onChange={(v) => setList(list.map((i) => i.id === u.id ? { ...i, active: v } : i))} />
                      <span className={`text-xs font-bold ${u.active ? "text-success" : "text-gray-400"}`}>{u.active ? "نشط" : "موقوف"}</span>
                    </div>
                  </td>
                  <td className="td">
                    <div className="flex gap-1">
                      <button className="icon-btn text-info hover:bg-info hover:text-white"><i className="fa-solid fa-pen" /></button>
                      <button className="icon-btn text-danger hover:bg-danger hover:text-white"><i className="fa-solid fa-trash" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
