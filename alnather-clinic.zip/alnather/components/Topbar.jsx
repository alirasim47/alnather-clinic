"use client";
import React from "react";
import { longDate } from "@/lib/utils";

export default function Topbar({ title }) {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between border-b border-gray-200 bg-white px-6 py-3.5 shadow-sm">
      <h1 className="text-lg font-extrabold text-primary">{title}</h1>

      <div className="flex items-center gap-5">
        <span className="hidden items-center gap-2 text-sm text-gray-500 md:flex">
          <i className="fa-regular fa-calendar-days text-accent" />
          {longDate()}
        </span>

        <button className="relative flex h-10 w-10 items-center justify-center rounded-lg text-gray-500 transition hover:bg-gray-100">
          <i className="fa-regular fa-bell text-lg" />
          <span className="absolute right-2 top-2 h-2.5 w-2.5 rounded-full border-2 border-white bg-danger" />
        </button>

        <span className="h-8 w-px bg-gray-200" />

        <div className="flex items-center gap-3">
          <div className="text-left">
            <div className="text-sm font-extrabold leading-none text-gray-800">أبو حسين</div>
            <div className="mt-1 text-[11px] font-bold text-accent">مدير النظام</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary font-black text-accent ring-2 ring-accent">
            أح
          </div>
        </div>
      </div>
    </header>
  );
}
