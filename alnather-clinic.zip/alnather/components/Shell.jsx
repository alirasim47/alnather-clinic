"use client";
import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Dashboard from "@/screens/Dashboard";
import Patients from "@/screens/Patients";
import Followups from "@/screens/Followups";
import Examiners from "@/screens/Examiners";
import Invoices from "@/screens/Invoices";
import Products from "@/screens/Products";
import Reports from "@/screens/Reports";
import Users from "@/screens/Users";
import Settings from "@/screens/Settings";

const TITLES = {
  dashboard: "لوحة التحكم", patients: "إدارة المرضى", followups: "تنبيهات المراجعات",
  examiners: "الفاحصون والكادر", invoices: "الفواتير والمبيعات", products: "المنتجات والمخزون",
  reports: "التقارير", users: "المستخدمون والصلاحيات", settings: "الإعدادات",
};

export default function Shell({ onLogout }) {
  const [page, setPage] = useState("dashboard");

  return (
    <div className="min-h-screen bg-surface">
      <Sidebar page={page} setPage={setPage} onLogout={onLogout} />
      <div className="mr-64 flex min-h-screen flex-col">
        <Topbar title={TITLES[page]} />
        <main className="flex-1 p-6">
          {page === "dashboard" && <Dashboard go={setPage} />}
          {page === "patients"  && <Patients />}
          {page === "followups" && <Followups />}
          {page === "examiners" && <Examiners />}
          {page === "invoices"  && <Invoices />}
          {page === "products"  && <Products />}
          {page === "reports"   && <Reports />}
          {page === "users"     && <Users />}
          {page === "settings"  && <Settings />}
        </main>
      </div>
    </div>
  );
}
