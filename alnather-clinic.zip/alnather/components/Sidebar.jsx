"use client";
import React from "react";

const NAV = [
  { id: "dashboard",  label: "الرئيسية",            icon: "fa-house" },
  { id: "patients",   label: "المرضى",              icon: "fa-users" },
  { id: "followups",  label: "تنبيهات المراجعات",    icon: "fa-bell" },
  { id: "examiners",  label: "الفاحصون",            icon: "fa-user-doctor" },
  { id: "invoices",   label: "الفواتير والمبيعات",   icon: "fa-file-invoice-dollar" },
  { id: "products",   label: "المنتجات",            icon: "fa-boxes-stacked" },
  { id: "reports",    label: "التقارير",            icon: "fa-chart-column" },
  { id: "users",      label: "المستخدمون",          icon: "fa-user-shield" },
  { id: "settings",   label: "الإعدادات",           icon: "fa-gear" },
];

export default function Sidebar({ page, setPage, onLogout }) {
  return (
    <aside className="fixed inset-y-0 right-0 z-40 flex w-64 flex-col bg-primary text-white">
      <div className="flex items-center gap-3 border-b border-white/10 px-5 py-5">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-primary">
          <i className="fa-solid fa-eye text-xl" />
        </span>
        <div>
          <div className="text-lg font-black leading-none">الناظر</div>
          <div className="mt-1 text-[11px] text-white/60">لإدارة عيادات فحص النظر والبصريات</div>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {NAV.map((item) => {
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-bold transition
                ${active
                  ? "bg-accent text-primary shadow-md"
                  : "text-white/70 hover:bg-white/10 hover:text-white"}`}
            >
              <i className={`fa-solid ${item.icon} w-5 text-center`} />
              {item.label}
              {item.id === "followups" && (
                <span className="mr-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-danger px-1 text-[10px] font-black text-white">
                  2
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-white/10 p-3">
        <button
          onClick={onLogout}
          className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-bold text-white/70 transition hover:bg-danger hover:text-white"
        >
          <i className="fa-solid fa-right-from-bracket w-5 text-center" />
          تسجيل الخروج
        </button>
      </div>
    </aside>
  );
}
