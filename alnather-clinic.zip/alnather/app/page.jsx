"use client";
import React, { useState } from "react";
import Shell from "@/components/Shell";

export default function Home() {
  const [authed, setAuthed] = useState(false);
  if (!authed) return <Login onLogin={() => setAuthed(true)} />;
  return <Shell onLogout={() => setAuthed(false)} />;
}

function Login({ onLogin }) {
  const [u, setU] = useState("admin");
  const [p, setP] = useState("••••••••");
  return (
    <div className="flex min-h-screen items-center justify-center bg-primary p-4">
      <div className="w-full max-w-md rounded-xl2 bg-white p-8 shadow-pop">
        <div className="mb-8 text-center">
          <span className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-accent shadow-lg">
            <i className="fa-solid fa-eye text-3xl" />
          </span>
          <h1 className="text-3xl font-black text-primary">الناظر</h1>
          <p className="mt-1.5 text-sm text-gray-500">لإدارة عيادات فحص النظر والبصريات</p>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); onLogin(); }} className="space-y-4">
          <div className="relative">
            <input
              className="input pr-11" placeholder="اسم المستخدم" value={u}
              onChange={(e) => setU(e.target.value)}
            />
            <i className="fa-regular fa-user absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <div className="relative">
            <input
              type="password" className="input pr-11" placeholder="كلمة المرور" value={p}
              onChange={(e) => setP(e.target.value)}
            />
            <i className="fa-solid fa-lock absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-sm text-gray-600">
            <input type="checkbox" defaultChecked className="h-4 w-4 accent-yellow-500" />
            تذكرني على هذا الجهاز
          </label>

          <button type="submit" className="btn-accent w-full py-3 text-base">
            <i className="fa-solid fa-right-to-bracket" /> تسجيل الدخول
          </button>
        </form>

        <p className="mt-6 text-center text-[11px] text-gray-400">
          الناظر v1.0.0 — أغسطس 2026
        </p>
      </div>
    </div>
  );
}
